﻿using System;
namespace MainPlugin
{
	interface IMultiServicePluginAction
	{
		object ExecuteServiceAction(string data);
		IServicePluginContext ServiceContext { get; }
	}
}
