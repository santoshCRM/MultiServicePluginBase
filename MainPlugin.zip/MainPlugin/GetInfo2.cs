﻿using MainPlugin;
using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MainPlugin
{
    public class GetInfo2 : MultiServicePluginActionBase<GetInfo2.Request, ResultSetResponse>
    {
         #region Constructors

        public GetInfo2(IServicePluginContext context) : base(context) { }

        #endregion
        public override ResultSetResponse ExecuteAction(Request request)
        {
            var response = new ResultSetResponse();

            response.EntityName = "sav_demoentity";
            IList<Entity> entities = new List<Entity>();
            for (int x = 0; x < 2; x++)
            {
                Entity entity = new Entity("sav_demoentity");
                entity.Id = Guid.NewGuid();
                entity["sav_name"] = "GetInfo2";
                entities.Add(entity);
            }
            response.Entities = entities;
            return response;
        }
        #region Request/Response Classes

        public class Request
        {
            public string ProductDescription;
            public string ProductSku;
            public string ProductCategory;
            public string ProductBusinessLine;
            public string ProductFamily;
            public string ProductBrand;
            public string ISOCode;
            public int? UserLcid;
            public string AccountID;
            public string CaseId;
        }

        #endregion
    }
}
