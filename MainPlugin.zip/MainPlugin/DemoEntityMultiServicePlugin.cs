﻿using MainPlugin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MainPlugin
{
   public class DemoEntityMultiServicePlugin: MultiServicePluginBase
    {
        #region Constructors/Destructors

        public DemoEntityMultiServicePlugin() : base() { }
        public DemoEntityMultiServicePlugin(string unsecureConfig, string secureConfig) : base(unsecureConfig, secureConfig) { }

        #endregion

        protected override IEnumerable<Type> GetRegisteredTypes()
        {
            return new Type[] {
				typeof( GetInfo1),
                typeof( GetInfo2)
			};
        }
    }
}
